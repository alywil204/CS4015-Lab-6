package com.designpatterns.facade;

public class Tweet {
}
